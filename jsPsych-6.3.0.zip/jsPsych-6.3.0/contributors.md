The following people have contributed to the development of jsPsych by writing code, documentation, and/or suggesting improvements (in alphabetical order):
* alisdt - https://github.com/alisdt
* Antonia - https://github.com/Ahoidal
* aucuparia - https://github.com/aucuparia
* Xiaolu Bai - https://github.com/lbai001
* bjoluc - https://github.com/bjoluc
* Christian Brickhouse - https://github.com/chrisbrickhouse
* Teon L Brooks - https://github.com/teonbrooks
* Eamon Caddigan - https://github.com/eamoncaddigan
* Jason Carpenter
* Steve Chao - https://github.com/stchao
* Zhanwen "Phil" Chen - https://github.com/zhanwenchen
* cthorey - https://github.com/cthorey
* Guy Davidson - https://github.com/guydav
* Kristin Diep - https://github.com/kristiyip
* Ari Dyckovsky - https://github.com/aridyckovsky
* Etienne Gaudrain - https://github.com/egaudrain
* Jon Gauthier - https://github.com/hans
* Robert Gibboni - https://github.com/r-b-g-b
* Becky Gilbert - https://github.com/becky-gilbert
* Mark Gorenstein - https://github.com/mgorenstein
* Rui Han - https://github.com/hrcn
* Andy Heusser - https://github.com/andrewheusser
* Angus Hughes - https://github.com/awhug
* Gustavo Juantorena - https://github.com/GEJ1
* Chris Jungerius - https://github.com/cjungerius
* George Kachergis - https://github.com/kachergis
* Yul Kang - https://github.com/yulkang
* Spencer King - https://github.com/spencerking
* Jana Klaus - https://github.com/janakl4us
* Arnold Kochari - https://github.com/akochari
* Peter Jes Kohler - https://github.com/pjkohler 
* kupiqu - https://github.com/kupiqu
* Daiichiro Kuroki - https://github.com/kurokida
* Jonas Lambers
* madebyafox - https://github.com/madebyafox
* Shane Martin - https://github.com/shamrt
* Vijay Marupudi - https://github.com/vijaymarupudi
* Adrian Oesch - https://github.com/adrianoesch
* Benjamin Ooghe-Tabanou - https://github.com/boogheta
* Dillon Plunkett - https://github.com/dillonplunkett
* Junyan Qi - https://github.com/GavinQ1
* Sivananda Rajananda - https://github.com/vrsivananda
* Dan Rivas - https://github.com/rivasd
* Werner Sævland - https://github.com/wernersa
* Marian Sauter - https://github.com/mariansauter
* Ellen Shapiro - https://github.com/designatednerd
* Jan Simson - https://github.com/jansim
* Hannah Small - https://github.com/hesmall
* sprengholz - https://github.com/sprengholz
* Dominik Strohmeier - https://github.com/onkeltom
* Nabeel Sulieman - https://github.com/nabsul
* Hitoshi Tominaga - https://github.com/tbrotherm
* Tim Vergenz - https://github.com/vergenzt
* Matteo Visconti di Oleggio Castello - https://github.com/mvdoc
* Ilya Vorontsov - https://github.com/VorontsovIE
* Wolfgang Walther - https://github.com/wolfgangwalther
* Erik Weitnauer - https://github.com/eweitnauer
* Rob Wilkinson - https://github.com/RobAWilkinson
* Andy Woods - https://github.com/andytwoods
* Reto Wyss - https://github.com/retowyss